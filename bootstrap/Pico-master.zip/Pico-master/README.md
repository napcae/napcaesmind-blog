Pico
====

Pico is a stupidly simple, blazing fast, flat file CMS. See http://pico.dev7studios.com for more info.